import os

_db_url = os.environ.get("DATABASE_URL", "postgres://username:password@host/db_name")
_db_url = _db_url.replace("postgresql://", "postgres://", 1)
if "?" in _db_url:
    _db_url = _db_url.split("?")[0]

TORTOISE = {
    "connections": {
        "default": _db_url,
    },
    "apps": {
        "models": {
            "models": [
                "models.misc",
                "models",
                "aerich.models"
            ],
            "default_connection": "default",
        }
    }
}

EXTENSIONS = [
    "cogs.esports",
    "cogs.events",
    "cogs.mod",
    "cogs.premium",
    "cogs.quomisc",
    "cogs.reminder",
    "cogs.utility",
    "server",
]

SERVER_PORT = int(os.environ.get("PORT", 8000))


DISCORD_TOKEN = os.environ.get("DISCORD_TOKEN", "")


COLOR = 0x00BFFF
FOOTER = "Quotient Prime | Provided by Nobita"
PREFIX = "q"
PRIME_EMOJI = "⚡"
OWNER_ID = "1468235754026172427"
DEVS = [1468235754026172427]

SERVER_LINK = "https://github.com/CycloneAddons/Quotient-Legacy"
SERVER_ID = None
TOURNEY_CSV_CHANNEL = None
EMOJIS_SERVER = []

BOT_INVITE = "https://discord.com/oauth2/authorize?client_id=1512041123529494709&permissions=8&scope=bot+applications.commands"

ACTIVITIES = [
    {"type": "playing", "name": "scrims across {servers} servers"},
    {"type": "listening", "name": "strategic calls from {members} players"},
    {"type": "watching", "name": "tournament brackets update in real time"},
    {"type": "competing", "name": "to lead the eSports automation arena"},
    {"type": "streaming", "name": "live event analytics", "url": "https://twitch.tv/Quotient"},
]


# LOGS
SHARD_LOG = "..."
ERROR_LOG = "..."
PUBLIC_LOG = "..."


# IGNORE RIGHT NOW
WEBSITE = "https://github.com/CycloneAddons/Quotient-Legacy"
REPOSITORY = "https://github.com/CycloneAddons/Quotient-Legacy"
FASTAPI_URL = "https://ocr.gfxvisual.xyz"
FASTAPI_KEY = "cyclonestrongsecret"
