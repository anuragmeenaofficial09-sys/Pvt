from __future__ import annotations

from contextlib import suppress
from functools import wraps
from typing import TYPE_CHECKING, Any, Callable

import discord

from core.Context import Context

from .cache import CacheManager
from .Cog import Cog

__all__ = ("right_bot_check", "event_bot_check", "role_command_check")


class right_bot_check:
    def __call__(self, fn: Callable) -> Callable:
        @wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any):
            if TYPE_CHECKING:
                from .Bot import Quotient

            if isinstance(args[0], Cog):
                bot: Quotient = args[0].bot

            else:
                bot: Quotient = args[0]  # type: ignore

            with suppress(AttributeError):
                for arg in args:
                    # check for both guild and guild_id
                    if hasattr(arg, "guild"):
                        guild_id = arg.guild.id
                        break
                    elif hasattr(arg, "guild_id"):
                        guild_id = arg.guild_id
                        break
                else:
                    _obj = kwargs.get("guild") or kwargs.get("guild_id")
                    # guild id can be none here
                    guild_id = _obj.id if isinstance(_obj, discord.Guild) else _obj

                if guild_id is not None and not await CacheManager.match_bot_guild(guild_id, bot.user.id):
                    return

            return await fn(*args, **kwargs)

        return wrapper


class event_bot_check:
    def __init__(self, bot_id: int):
        self.bot_id = bot_id

    def __call__(self, fn: Callable) -> Callable:
        @wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any):
            bot_id: int = args[0].bot.user.id
            return await fn(*args, **kwargs) if bot_id == self.bot_id else None

        return wrapper


class role_command_check:
    def __call__(self, fn: Callable) -> Callable:
        @wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any):
            _, ctx, *rest = args

            role: discord.Role = rest[0] if rest else kwargs.get("role")
            ctx: Context  # type: ignore

            if role is None:
                return await fn(*args, **kwargs)

            if role.managed:
                return await ctx.error(f"❌ `{role.name}` is an integrated/managed role and cannot be assigned manually.")

            if ctx.me.top_role.position <= role.position:
                return await ctx.error(
                    f"❌ I can't manage `{role.name}` because it's above my highest role (`{ctx.me.top_role.name}`).\n"
                    f"Move my role above `{role.name}` in Server Settings → Roles."
                )

            if ctx.author != ctx.guild.owner and ctx.author.top_role.position <= role.position:
                return await ctx.error(
                    f"❌ `{role.name}` is above your highest role (`{ctx.author.top_role.name}`). You can't manage it."
                )

            if role.permissions.administrator:
                return await ctx.error(f"❌ `{role.name}` has **Administrator** permission — cannot assign it for safety.")

            return await fn(*args, **kwargs)

        return wrapper
