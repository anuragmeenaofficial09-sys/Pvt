from __future__ import annotations

from difflib import get_close_matches
from typing import List, Mapping

import discord
from discord.ext import commands

import config
from models import Guild, User
from utils import LinkButton, LinkType, QuoPaginator, discord_timestamp, truncate_string, emote

from .Cog import Cog


class HelpCommand(commands.HelpCommand):
    def __init__(self) -> None:
        super().__init__(
            verify_checks=False,
            command_attrs={
                "cooldown": commands.CooldownMapping.from_cooldown(1, 8.0, commands.BucketType.member),
                "help": "Shows help about the bot, a command, or a category",
            },
        )

    @property
    def color(self):
        return self.context.bot.color

    async def send_bot_help(self, mapping: Mapping[Cog, List[commands.Command]]):
        ctx = self.context

        hidden = ("HelpCog", "Dev")

        embed = discord.Embed(color=self.color)

        dashboard = f"[Privacy Policy](https://github.com/quotientbot/Quotient-Bot/wiki/privacy-policy)"
        desc_parts = [dashboard]

        _valid_server = config.SERVER_LINK.startswith("http")
        _valid_invite = config.BOT_INVITE.startswith("http")

        if _valid_server:
            desc_parts.insert(0, f"[Support Server]({config.SERVER_LINK})")
        if _valid_invite:
            desc_parts.insert(1 if _valid_server else 0, f"[Invite Me]({config.BOT_INVITE})")

        embed.description = " **|** ".join(desc_parts) + "\n\n"

        guild = await Guild.get_or_none(pk=ctx.guild.id)
        if guild and guild.is_premium:
            if _valid_server:
                embed.description += f"{emote.top_user} [__Server Premium ending:__]({config.SERVER_LINK}) *`forever (or until Cyclone dies)`*"
            else:
                embed.description += f"{emote.top_user} __Server Premium__ *`forever (or until Cyclone dies)`*"

        user = await User.get_or_none(user_id=ctx.author.id)
        is_dev = user.is_dev if user else False

        for cog, cmds in mapping.items():
            if not is_dev and (not cog or cog.qualified_name in hidden):
               continue
            if is_dev:
               filtered_cmds = cmds
            else:
                filtered_cmds = await self.filter_commands(cmds, sort=True)

            if not filtered_cmds:
                continue

            commands_list = ", ".join(map(lambda x: f"`{x}`", filtered_cmds))
            if len(commands_list) > 1024:
                commands_list = commands_list[:1021] + "..."
            embed.add_field(
                inline=False,
                name=cog.qualified_name.title() if cog else "No Category",
                value=commands_list,
            )

        try:
            slash_cmds = await ctx.bot.tree.fetch_commands()
            slash_cmds_value = ", ".join(f"{i.mention}" for i in slash_cmds)
            if slash_cmds_value:
                if len(slash_cmds_value) > 1024:
                    slash_cmds_value = slash_cmds_value[:1021] + "..."
                embed.add_field(name="Slash Commands", value=slash_cmds_value, inline=False)
        except Exception:
            pass


        links = []
        if config.SERVER_LINK.startswith("http"):
            links.append(LinkType("Support Server", config.SERVER_LINK))
        if config.BOT_INVITE.startswith("http"):
            links.append(LinkType("Invite Me", config.BOT_INVITE))

        if links:
            await ctx.send(embed=embed, embed_perms=True, view=LinkButton(links))
        else:
            await ctx.send(embed=embed, embed_perms=True)

    async def send_group_help(self, group: commands.Group):
        prefix = self.context.prefix

        if not group.commands:
            return await self.send_command_help(group)

        embed = discord.Embed(color=discord.Color(self.color))

        embed.title = f"{group.qualified_name} {group.signature}"
        _help = group.help or "No description provided..."

        _cmds = "\n".join(f"`{prefix}{c.qualified_name}` : {truncate_string(c.short_doc,60)}" for c in group.commands)

        embed.description = f"> {_help}\n\n**Subcommands**\n{_cmds}"

        embed.set_footer(text=f'Use "{prefix}help <command>" for more information.')

        if group.aliases:
            embed.add_field(
                name="Aliases",
                value=", ".join(f"`{aliases}`" for aliases in group.aliases),
                inline=False,
            )

        examples = []
        if group.extras:
            if _gif := group.extras.get("gif"):
                embed.set_image(url=_gif)

            if _ex := group.extras.get("examples"):
                examples = [f"{self.context.prefix}{i}" for i in _ex]

        if examples:
            examples: str = "\n".join(examples)  # type: ignore
            embed.add_field(name="Examples", value=f"```{examples}```")

        await self.context.send(embed=embed, embed_perms=True)

    async def send_cog_help(self, cog: Cog):
        paginator = QuoPaginator(self.context, per_page=14)
        c = 0
        for cmd in cog.get_commands():
            if not cmd.hidden:
                _brief = "No Information..." if not cmd.short_doc else truncate_string(cmd.short_doc, 60)
                paginator.add_line(f"`{cmd.qualified_name}` : {_brief}")
                c += 1

        paginator.title = f"{cog.qualified_name.title()} ({c})"
        await paginator.start()

    async def send_command_help(self, cmd: commands.Command):
        embed = discord.Embed(color=self.color)
        embed.title = "Command: " + cmd.qualified_name

        examples = []

        alias = ",".join((f"`{alias}`" for alias in cmd.aliases)) if cmd.aliases else "No aliases"
        _text = (
            f"**Description:** {cmd.help or 'No help found...'}\n"
            f"**Usage:** `{self.get_command_signature(cmd)}`\n"
            f"**Aliases:** {alias}\n"
            f"**Examples:**"
        )

        if cmd.extras:
            if _gif := cmd.extras.get("gif"):
                embed.set_image(url=_gif)

            if _ex := cmd.extras.get("examples"):
                examples = [f"{self.context.prefix}{i}" for i in _ex]

        examples: str = "\n".join(examples) if examples else "Command has no examples"  # type: ignore

        _text += f"```{examples}```"

        embed.description = _text

        await self.context.send(embed=embed, embed_perms=True)

    async def command_not_found(self, string: str):
        message = f"Could not find the `{string}` command. "
        commands_list = (str(cmd) for cmd in self.context.bot.walk_commands())

        if dym := "\n".join(get_close_matches(string, commands_list)):
            message += f"Did you mean...\n{dym}"

        return message
