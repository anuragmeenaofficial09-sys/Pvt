from __future__ import annotations

import os
import secrets

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile, status
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.templating import Jinja2Templates

fastapi_app = FastAPI()
security = HTTPBasic()

# Templates directory relative to src/ (bot's CWD)
templates = Jinja2Templates(directory="server/templates")

_bot = None
_password = os.environ.get("DASHBOARD_PASSWORD", "admin123")


def set_bot(bot):
    global _bot, _password
    _bot = bot
    _password = os.environ.get("DASHBOARD_PASSWORD", "admin123")


def verify_auth(credentials: HTTPBasicCredentials = Depends(security)):
    correct_user = secrets.compare_digest(credentials.username.encode(), b"admin")
    correct_pass = secrets.compare_digest(credentials.password.encode(), _password.encode())
    if not (correct_user and correct_pass):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Wrong password",
            headers={"WWW-Authenticate": "Basic realm='Bot Dashboard'"},
        )
    return True


@fastapi_app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, _: bool = Depends(verify_auth)):
    bot_user = _bot.user if _bot else None
    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "bot_name": bot_user.name if bot_user else "Bot",
            "bot_avatar": str(bot_user.display_avatar.url) if bot_user else "",
            "guild_count": len(_bot.guilds) if _bot else 0,
        },
    )


@fastapi_app.post("/api/change-username")
async def change_username(username: str = Form(...), _: bool = Depends(verify_auth)):
    if not _bot:
        return JSONResponse({"success": False, "error": "Bot not ready"}, status_code=503)
    try:
        await _bot.user.edit(username=username)
        return JSONResponse({"success": True, "username": username})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=400)


@fastapi_app.post("/api/change-bio")
async def change_bio(bio: str = Form(...), _: bool = Depends(verify_auth)):
    if not _bot:
        return JSONResponse({"success": False, "error": "Bot not ready"}, status_code=503)
    try:
        await _bot.user.edit(bio=bio)
        return JSONResponse({"success": True})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=400)


@fastapi_app.post("/api/change-avatar")
async def change_avatar(avatar: UploadFile = File(...), _: bool = Depends(verify_auth)):
    if not _bot:
        return JSONResponse({"success": False, "error": "Bot not ready"}, status_code=503)
    try:
        data = await avatar.read()
        await _bot.user.edit(avatar=data)
        return JSONResponse({"success": True, "avatar_url": str(_bot.user.display_avatar.url)})
    except Exception as e:
        return JSONResponse({"success": False, "error": str(e)}, status_code=400)


@fastapi_app.get("/api/bot-info")
async def bot_info(_: bool = Depends(verify_auth)):
    if not _bot:
        return JSONResponse({"success": False, "error": "Bot not ready"}, status_code=503)
    return JSONResponse(
        {
            "success": True,
            "username": _bot.user.name,
            "avatar_url": str(_bot.user.display_avatar.url),
            "guild_count": len(_bot.guilds),
            "latency": round(_bot.latency * 1000),
        }
    )


@fastapi_app.get("/uptime")
async def uptime_check():
    """Public health check endpoint for UptimeRobot — no auth needed."""
    import time
    from datetime import datetime, timezone

    bot_ready = _bot is not None and _bot.is_ready()
    return JSONResponse({
        "status": "online" if bot_ready else "starting",
        "bot": _bot.user.name if bot_ready else "starting",
        "guilds": len(_bot.guilds) if bot_ready else 0,
        "latency_ms": round(_bot.latency * 1000) if bot_ready else 0,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    })


from .payment import router as payment_router

fastapi_app.include_router(payment_router)
