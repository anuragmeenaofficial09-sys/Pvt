red = "<:red:1512043832664129618>"
green = "<:green:1512043835805405215>"
yellow = "<:yellow:1512043841568505876>"
invisible = "<:invisible:1512043846161272913>"

scrimscheck = "<:scrimscheck:1512043849994993724>"
scrimsxmark = "<:scrimscross:1512043853623066775>"

info = "<:info2:1512043857024647188>"
trash = "<:trashcan:1512043860644331661>"
exit = "<:exit:1512043864565743686>"


add = "<:add:1512043867955003493>"
remove = "<:remove:1512043871234953298>"
edit = "<:edit:1512043874829205614>"

diamond = "<a:diamond:1512043878566330448>"

error = "❗"

server = "<:server:1512043882915823669>"
privacy = "<:privacy:1512043885944377386>"

one = "1️⃣"
two = "2️⃣"
three = "3️⃣"
four = "4️⃣"
five = "5️⃣"


rps = "<:rps:1512043888406429748>"


bravery = "<:bravery:1512043892055343245>"
brilliance = "<:brilliance:1512043896371413132>"
balance = "<:balance:1512043899600765200>"

supporter = "<:supporter:1512043903430168606>"
staff = "<:staff:1512043906966225027>"
partner = "<:partner:1512043910128603238>"
hypesquad = "<:hypesquad:1512043913882374234>"
hypesquad_events = "<:hypesquad_events:1512043917464572034>"
bug_hunter = "<:bug_hunter:1512043920744513597>"
BugHunterLvl2 = "<:bug_hunter2:1512043924422656091>"
bot = "<:bot:1512043928390602793>"
bot_devloper = "<:bot_devloper:1512043932085915699>"
verified_bot = "<:verifiedbot1:1512043935780835421><:verifiedbot2:1512043940059287663>"

white_arrow = "<:arrow:1512043942990970931>"
check = "<:check:1512043946090565783>"
xmark = "<:xmark:1512043950154977350>"
loading = "<a:loading:1512043954307076219>"
VoiceChannel = "<:voice:1512043957750599843>"
TextChannel = "<:text:1512043961353638059>"
category = "<:category:1512043964641968138>"
pain = "<:blobpain:1512043967456481381>"
settings_yes = "<:settings_mark_off:1512043971264774215><:settings_check_on:1512043974674743316>"
settings_no = "<:set_no_on:1512043977904361663><:set_yes_off:1512043981490491484>"


pstop = "<:stop:1512043985391058964>"
pprevious = "<:previous:1512043989572780164>"
pnext = "<:next:1512043992945000558>"
plast = "<:last:1512043996376207530>"
pfirst = "<:first:1512043999689445456>"


red1 = "<:red1:1512044002734772364>"
red2 = "<:red2:1512044006782271588>"
red3 = "<:red3:1512044010234183733>"
red4 = "<:red4:1512044013577048085>"
red5 = "<:red5:1512044017397927966>"


green1 = "<:green1:1512044021122596935>"
green2 = "<:green2:1512044024729571338>"
green3 = "<:green3:1512044029498626100>"
green4 = "<:green4:1512044033411645501>"
green5 = "<:green5:1512044036721086494>"

#shifted emojies from files
left         = "<:left:1512044039921340588>"
right        = "<:right:1512044043603939410>"
refresh      = "<:refresh:1512044047458369658>"
double_left  = "<:double_left:1512044051841683576>"
double_right = "<:double_right:1512044055779868703>"
youtube      = "<:youtube:1512044061001777193>"
instagram    = "<:instagram:1512044064474660864>"
rooter       = "<:rooter:1512044068430020678>"
loco         = "<:loco:1512044071755972660>"
hehe         = "<:hehe:1512044075875041421>"
rooCoder     = "<a:rooCoder:1512044080606085130>"
pain         = "<:pain:1512044084376637610>"
text         = "<:text:1512043961353638059>"
swap         = "<:swap:1512044087866298428>"
plant        = "<:plant:1512044091532247190>"
c_c          = "<:c_:1512044094715596914>"
roocool      = "<a:roocool:1512044098960359556>"
top_user     = "<a:top_user:1512044103792066691>"
premium      = "<a:premium:1512044108816973898>"
BADGES = {
    "creator": "<:creator:1512044112122089504>",
    "dev": "<:dev:1512044115951616040>",
    "donator": "<a:donator:1512044120921866260>",
    "messenger": "<a:messenger:1512044127737479400>",
    "premium": "<a:premium:1512044108816973898>",
    "contributor": "<a:contributor:1512044131772272762>",
    "staff": "<:staff:1512043906966225027>",
    "top_user": "<a:top_user:1512044103792066691>",
    "voter": "<:voter:1512044136109183016>",
}

p = "\U0001f1f5"
e = "\U0001f1ea"
r = "\U0001f1f7"
eye = "👀"
