from __future__ import annotations

from contextlib import suppress

import discord

from models import Scrim

from ...views.base import EsportsBaseView

__all__ = ("ScrimsView", "ScrimsButton")


class ScrimsView(EsportsBaseView):
    record: Scrim

    def __init__(self, ctx, **kwargs):
        super().__init__(ctx, **kwargs)

    async def on_error(self, interaction: discord.Interaction, error: Exception, item) -> None:
        from utils.exceptions import InputError

        print("Scrims View Error:", error)

        if isinstance(error, InputError):
            with suppress(discord.HTTPException):
                msg = str(error)
                if interaction.response.is_done():
                    await interaction.followup.send(
                        embed=discord.Embed(description=msg, color=discord.Color.red()),
                        ephemeral=True,
                    )
                else:
                    await interaction.response.send_message(
                        embed=discord.Embed(description=msg, color=discord.Color.red()),
                        ephemeral=True,
                    )
            return

        self.ctx.bot.dispatch("command_error", self.ctx, error)


class ScrimsButton(discord.ui.Button):
    view: ScrimsView

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
