from __future__ import annotations

import typing

if typing.TYPE_CHECKING:
    from core import Quotient
import config

import itertools
from collections import Counter
from datetime import datetime, timedelta, timezone

import discord
import pkg_resources
import psutil
import pygit2
from discord import Embed, Color, app_commands
from discord.ext import commands

from cogs.quomisc.helper import format_relative
from core import Cog, Context, QuotientView
from models import Commands, Guild, User, Votes
from utils import LinkButton, LinkType, QuoColor, checks, get_ipm, human_timedelta, truncate_string, emote

from .alerts import *
from .dev import *
from .views import MoneyButton, SetupButtonView, VoteButton


class Quomisc(Cog, name="quomisc"):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(aliases=("inv",))
    async def invite(self, ctx: Context):
        """Invite Quotient Prime to your server."""
        v = discord.ui.View(timeout=None)
        if self.bot.config.BOT_INVITE.startswith("http"):
            v.add_item(
                discord.ui.Button(
                    style=discord.ButtonStyle.link, label="Invite Quotient Prime", url=self.bot.config.BOT_INVITE
                )
            )
        if self.bot.config.SERVER_LINK.startswith("http"):
            v.add_item(
                discord.ui.Button(
                    style=discord.ButtonStyle.link, label="Support Server", url=self.bot.config.SERVER_LINK
                )
            )
        embed = discord.Embed(
            title="Invite Quotient Prime",
            description="Click the button below to invite me to your server!",
            color=self.bot.color
        )
        embed.set_footer(text=self.bot.config.FOOTER)
        await ctx.reply(embed=embed, view=v)

    async def make_private_channel(self, ctx: Context) -> discord.TextChannel:
        support_link = f"[Support Server]({ctx.config.SERVER_LINK})"
        invite_link = f"[Invite Me]({ctx.config.BOT_INVITE})"
        vote_link = f"[Vote]({ctx.config.WEBSITE}/vote)"
        source = f"[Source]({ctx.config.REPOSITORY})"

        guild = ctx.guild
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            guild.me: discord.PermissionOverwrite(
                read_messages=True,
                send_messages=True,
                read_message_history=True,
                embed_links=True,
                attach_files=True,
                manage_channels=True,
            ),
            ctx.author: discord.PermissionOverwrite(read_messages=True, send_messages=True, read_message_history=True),
        }
        channel = await guild.create_text_channel(
            "quotient-private", overwrites=overwrites, reason=f"Made by {str(ctx.author)}"
        )
        await Guild.filter(guild_id=ctx.guild.id).update(private_channel=channel.id)

        e = self.bot.embed(ctx)
        e.add_field(
            name="**What is this channel for?**",
            inline=False,
            value="This channel is made for Quotient to send important announcements and activities that need your attention. If anything goes wrong with any of my functionality I will notify you here. Important announcements from the developer will be sent directly here too.\n\nYou can test my commands in this channel if you like. Kindly don't delete it , some of my commands won't work without this channel.",
        )
        e.add_field(
            name="**__Important Links__**", value=f"{support_link} | {invite_link} | {vote_link} | {source}", inline=False
        )

        links = [LinkType("Support Server", ctx.config.SERVER_LINK)]
        view = LinkButton(links)
        m = await channel.send(embed=e, view=view)
        await m.pin()

        return channel

    @commands.command(name="setup")
    @commands.has_permissions(manage_guild=True)
    @commands.bot_has_guild_permissions(manage_channels=True, manage_webhooks=True)
    async def setup_cmd(self, ctx: Context):
        """
        Setup Quotient in the current server.
        This creates a private channel in the server. You can rename that if you like.
        Quotient requires manage channels and manage wehooks permissions for this to work.
        You must have manage server permission.
        """

        _view = SetupButtonView(ctx)
        _view.add_item(QuotientView.tricky_invite_button())
        record = await Guild.get(guild_id=ctx.guild.id)

        if record.private_ch is not None:
            return await ctx.error(f"You already have a private channel ({record.private_ch.mention})", view=_view)
        channel = await self.make_private_channel(ctx)
        await ctx.success(f"Created {channel.mention}", view=_view)

    @commands.command(name="ping")
    @commands.cooldown(1, 5, commands.BucketType.member)
    async def ping(self, ctx: Context):
        """Check the bot's latency and response time."""
        import time

        start = time.perf_counter()
        msg = await ctx.send("🏓 Pinging...")
        end = time.perf_counter()

        api_latency = round((end - start) * 1000)
        ws_latency = round(self.bot.latency * 1000)

        embed = discord.Embed(color=self.bot.color)
        embed.title = "🏓 Pong!"
        embed.add_field(name="WebSocket", value=f"`{ws_latency}ms`", inline=True)
        embed.add_field(name="API", value=f"`{api_latency}ms`", inline=True)
        embed.set_footer(text=self.bot.config.FOOTER)

        await msg.edit(content=None, embed=embed)

    def get_bot_uptime(self, *, brief=False):
        return human_timedelta(self.bot.start_time, accuracy=None, brief=brief, suffix=False)

    @staticmethod
    def format_commit(commit):  # source: R danny
        short, _, _ = commit.message.partition("\n")
        short_sha2 = commit.hex[0:6]
        commit_tz = timezone(timedelta(minutes=commit.commit_time_offset))
        commit_time = datetime.fromtimestamp(commit.commit_time).astimezone(commit_tz)

        # [`hash`](url) message (offset)
        offset = format_relative(commit_time.astimezone(timezone.utc))
        return f"[`{short_sha2}`](https://github.com/CycloneAddons/Quotient-Legacy/commit/{commit.hex}) {truncate_string(short,40)} ({offset})"

    def get_last_commits(self, count=3):
       if not os.path.exists(".git"):
         return "⚠️ No .git directory found — not a git repository."

       try:
        repo = pygit2.Repository(".git")
        commits = list(itertools.islice(
            repo.walk(repo.head.target, pygit2.GIT_SORT_TOPOLOGICAL),
            count
        ))
        return "\n".join(self.format_commit(c) for c in commits) if commits else "ℹ️ No commits found."
       except Exception as e:
         return f"❌ Error reading git repository: {e}"

    @commands.command(aliases=("stats",))
    @commands.cooldown(1, 10, commands.BucketType.guild)
    async def about(self, ctx: Context):
        """Statistics of Quotient Prime."""
        db_latency = await self.bot.db_latency
        version = pkg_resources.get_distribution("discord.py").version

        total_memory = psutil.virtual_memory().total >> 20
        used_memory = psutil.virtual_memory().used >> 20
        cpu_used = str(psutil.cpu_percent())

        total_members = sum(g.member_count or 0 for g in self.bot.guilds)
        total_command_uses = await Commands.all().count()
        user_invokes = await Commands.filter(user_id=ctx.author.id, guild_id=ctx.guild.id).count() or 0
        server_invokes = await Commands.filter(guild_id=ctx.guild.id).count() or 0
        chnl_count = Counter(map(lambda ch: ch.type, self.bot.get_all_channels()))
        guild_value = len(self.bot.guilds)
        msges = self.bot.seen_messages

        embed = discord.Embed(color=self.bot.color)
        embed.title = f"{emote.bot} Quotient Prime — The Legacy Continues"
        embed.description = (
            f"⚡ A powerful Discord bot for Esports communities.\n"
            f"Built & Provided by **Nobita** with ❤️"
        )
        if ctx.config.SERVER_LINK.startswith("http"):
            embed.url = ctx.config.SERVER_LINK

        embed.set_thumbnail(url=self.bot.user.display_avatar.url)

        embed.add_field(
            name=f"{emote.server} Servers",
            value=f"**{guild_value:,}** total\n{len(self.bot.shards)} shards",
        )
        embed.add_field(
            name=f"{emote.eye} Uptime",
            value=f"{self.get_bot_uptime(brief=True)}\n{msges:,} msgs seen",
        )
        embed.add_field(
            name=f"{emote.brilliance} Members",
            value=f"**{total_members:,}** total",
        )
        embed.add_field(
            name=f"{emote.TextChannel} Channels",
            value=f"{chnl_count[discord.ChannelType.text]:,} text\n{chnl_count[discord.ChannelType.voice]:,} voice",
        )
        embed.add_field(
            name=f"{emote.info} Commands Used",
            value=f"**{total_command_uses:,}** globally\n{server_invokes:,} here\n{user_invokes:,} by you",
        )
        embed.add_field(
            name=f"{emote.settings_yes} System",
            value=f"🏓 {round(self.bot.latency * 1000, 1)}ms\n"
                  f"🗄️ {db_latency}\n"
                  f"💾 {used_memory}/{total_memory} MB\n"
                  f"🖥️ CPU {cpu_used}%",
        )

        embed.set_footer(
            text=f"discord.py v{version} | Powered by Nobita ⚡",
            icon_url=self.bot.user.display_avatar.url,
        )

        links = []
        if ctx.config.SERVER_LINK.startswith("http"):
            links.append(LinkType("Support Server", ctx.config.SERVER_LINK))
        if ctx.config.BOT_INVITE.startswith("http"):
            links.append(LinkType("Invite Me", ctx.config.BOT_INVITE))
        if links:
            await ctx.send(embed=embed, embed_perms=True, view=LinkButton(links))
        else:
            await ctx.send(embed=embed, embed_perms=True)


    @commands.command()
    async def voteremind(self, ctx: Context):
        """Get a reminder when your vote expires"""
        check = await Votes.get_or_none(user_id=ctx.author.id)
        if check:
            await Votes.filter(user_id=ctx.author.id).update(reminder=not (check.reminder))
            await ctx.success(f"Turned vote-reminder {'ON' if not check.reminder else 'OFF'}!")
        else:
            await Votes.create(user_id=ctx.author.id, reminder=True)
            await ctx.success(f"Turned vote-reminder ON!")

    @commands.command()
    @commands.has_permissions(manage_guild=True)
    async def prefix(self, ctx: Context, *, new_prefix: str = None):
        """Change your server's prefix"""

        if not new_prefix:
            prefix = self.bot.cache.guild_data[ctx.guild.id].get("prefix", self.bot.config.PREFIX)
            return await ctx.simple(f"Prefix for this server is `{prefix}`")

        if len(new_prefix) > 5:
            return await ctx.error(f"Prefix cannot contain more than 5 characters.")

        self.bot.cache.guild_data[ctx.guild.id]["prefix"] = new_prefix
        await Guild.filter(guild_id=ctx.guild.id).update(prefix=new_prefix)
        await ctx.success(f"Updated server prefix to: `{new_prefix}`")

    @commands.command()
    @commands.has_permissions(manage_guild=True)
    @checks.is_premium_guild()
    async def color(self, ctx: Context, *, new_color: QuoColor):
        """Change color of Quotient's embeds"""
        color = int(str(new_color).replace("#", ""), 16)  # The hex value of a color.

        self.bot.cache.guild_data[ctx.guild.id]["color"] = color
        await Guild.filter(guild_id=ctx.guild.id).update(embed_color=color)
        await ctx.success(f"Updated server color.")

    @commands.command()
    @checks.is_premium_guild()
    @commands.has_permissions(manage_guild=True)
    async def footer(self, ctx: Context, *, new_footer: str):
        """Change footer of embeds sent by Quotient"""
        if len(new_footer) > 50:
            return await ctx.success(f"Footer cannot contain more than 50 characters.")

        self.bot.cache.guild_data[ctx.guild.id]["footer"] = new_footer
        await Guild.filter(guild_id=ctx.guild.id).update(embed_footer=new_footer)
        await ctx.send(f"Updated server footer.")

    @commands.command()
    async def money(self, ctx: Context):
        user = await User.get(user_id=ctx.author.id)

        e = self.bot.embed(ctx, title="Your Quo Coins")
        e.set_thumbnail(url=self.bot.user.display_avatar.url)

        e.description = (
            f"💰 | You have a total of `{user.money} Quo Coins`.\n"
            f"*Quo Coins can be earned by voting [here]({ctx.config.WEBSITE}/vote)*"
        )

        _view = MoneyButton(ctx)
        if not user.money >= 120:
            _view.children[0] = discord.ui.Button(
                label=f"Claim Prime (120 coins)", custom_id="claim_prime", style=discord.ButtonStyle.grey, disabled=True
            )

        _view.message = await ctx.send(embed=e, embed_perms=True, view=_view)

    @commands.command()
    async def vote(self, ctx: Context):
        e = self.bot.embed(ctx, title="Vote for Quotient")
        e.description = (
            "**Rewards**\n"
            f"{emote.roocool} Voter Role `12 hrs`\n"
            f"{self.bot.config.PRIME_EMOJI} Quo Coin `x1`"
        )
        e.set_thumbnail(url=self.bot.user.display_avatar.url)

        _view = VoteButton(ctx)

        vote = await Votes.get_or_none(pk=ctx.author.id)
        if vote and vote.is_voter:
            _b: discord.ui.Button = discord.ui.Button(
                disabled=True,
                style=discord.ButtonStyle.grey,
                custom_id="vote_quo",
                label=f"Vote in {human_timedelta(vote.expire_time,accuracy=1,suffix=False)}",
            )
            _view.children[0] = _b

        e.set_footer(
            text=f"Your votes: {vote.total_votes if vote else 0}",
            icon_url=getattr(ctx.author.display_avatar, "url", self.bot.user.display_avatar.url),
        )
        _view.message = await ctx.send(embed=e, view=_view, embed_perms=True)

    @commands.command(aliases=("server", "guildinfo"))
    @commands.guild_only()
    @commands.cooldown(1, 5, commands.BucketType.guild)
    async def serverinfo(self, ctx: Context):
        """Shows detailed information about the current server."""
        guild = ctx.guild

        # Member counts
        total = guild.member_count or 0
        bots = sum(1 for m in guild.members if m.bot)
        humans = total - bots
        online = sum(1 for m in guild.members if m.status != discord.Status.offline and not m.bot)

        # Channel counts
        text_ch = len(guild.text_channels)
        voice_ch = len(guild.voice_channels)
        categories = len(guild.categories)
        forums = len([c for c in guild.channels if isinstance(c, discord.ForumChannel)])

        # Boost info
        boost_level = guild.premium_tier
        boosters = guild.premium_subscription_count or 0
        boost_bar = ["🔲"] * 14
        boost_filled = min(boosters, 14)
        for i in range(boost_filled):
            boost_bar[i] = "🟪"
        boost_display = "".join(boost_bar) + f" **{boosters}** boosts"

        # Verification & features
        verify_levels = {0: "None", 1: "Low", 2: "Medium", 3: "High", 4: "Very High"}
        verify = verify_levels.get(guild.verification_level.value, "Unknown")

        embed = discord.Embed(
            title=f"🏰 {guild.name}",
            color=self.bot.color,
            timestamp=discord.utils.utcnow(),
        )
        embed.description = guild.description or ""

        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        if guild.banner:
            embed.set_image(url=guild.banner.url)

        embed.add_field(
            name="👑 Owner",
            value=f"{guild.owner.mention if guild.owner else 'Unknown'}\n`{guild.owner_id}`",
        )
        embed.add_field(
            name="🆔 Server ID",
            value=f"`{guild.id}`",
        )
        embed.add_field(
            name="📅 Created",
            value=f"<t:{int(guild.created_at.timestamp())}:D>\n<t:{int(guild.created_at.timestamp())}:R>",
        )
        embed.add_field(
            name="👥 Members",
            value=f"👤 Humans: **{humans:,}**\n🟢 Online: **{online:,}**\n🤖 Bots: **{bots:,}**\n📊 Total: **{total:,}**",
        )
        embed.add_field(
            name="📢 Channels",
            value=f"💬 Text: **{text_ch}**\n🔊 Voice: **{voice_ch}**\n📁 Categories: **{categories}**\n🗒️ Forums: **{forums}**",
        )
        embed.add_field(
            name="🎭 Roles",
            value=f"**{len(guild.roles) - 1}** roles\n`@everyone` excluded",
        )
        embed.add_field(
            name="🚀 Boost Status",
            value=f"Level **{boost_level}** ⭐\n{boost_display}",
            inline=False,
        )
        embed.add_field(
            name="🔒 Verification",
            value=verify,
        )
        embed.add_field(
            name="😀 Emojis",
            value=f"**{len(guild.emojis)}** / {guild.emoji_limit}",
        )

        embed.set_footer(
            text=f"Quotient Prime | Provided by Nobita",
            icon_url=self.bot.user.display_avatar.url,
        )
        await ctx.send(embed=embed, embed_perms=True)

    @commands.command(aliases=("botstatus", "binfo"))
    @commands.cooldown(1, 10, commands.BucketType.guild)
    async def status(self, ctx: Context):
        """Shows full bot and server status information."""
        guild = ctx.guild

        # --- Bot Info ---
        ws_latency = round(self.bot.latency * 1000, 1)
        uptime_str = self.get_bot_uptime(brief=True)
        total_guilds = len(self.bot.guilds)
        total_members = sum(g.member_count or 0 for g in self.bot.guilds)
        total_commands = await Commands.all().count()
        cpu = psutil.cpu_percent()
        mem = psutil.virtual_memory()
        mem_used = mem.used >> 20
        mem_total = mem.total >> 20

        # --- Server Info ---
        total = guild.member_count or 0
        bots = sum(1 for m in guild.members if m.bot)
        humans = total - bots
        online = sum(1 for m in guild.members if m.status != discord.Status.offline and not m.bot)
        text_ch = len(guild.text_channels)
        voice_ch = len(guild.voice_channels)
        boost_level = guild.premium_tier
        boosters = guild.premium_subscription_count or 0
        verify_map = {0: "None", 1: "Low", 2: "Medium", 3: "High", 4: "Very High"}
        verify = verify_map.get(guild.verification_level.value, "Unknown")

        # --- Scrim / Tourney counts for this server ---
        from models import Scrim, Tourney
        scrim_count = await Scrim.filter(guild_id=guild.id).count()
        tourney_count = await Tourney.filter(guild_id=guild.id).count()

        embed = discord.Embed(
            color=self.bot.color,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_author(
            name=f"Quotient Prime — Full Status",
            icon_url=self.bot.user.display_avatar.url,
        )
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)

        # BOT section
        embed.add_field(
            name="🤖 Bot",
            value=(
                f"**Name:** {self.bot.user}\n"
                f"**ID:** `{self.bot.user.id}`\n"
                f"**Uptime:** {uptime_str}\n"
                f"**Shards:** {len(self.bot.shards)}"
            ),
        )
        embed.add_field(
            name="📡 Network",
            value=(
                f"**Ping:** `{ws_latency} ms`\n"
                f"**Servers:** `{total_guilds:,}`\n"
                f"**Members:** `{total_members:,}`\n"
                f"**Cmds Used:** `{total_commands:,}`"
            ),
        )
        embed.add_field(
            name="🖥️ System",
            value=(
                f"**CPU:** `{cpu}%`\n"
                f"**RAM:** `{mem_used}/{mem_total} MB`\n"
                f"**RAM Used:** `{mem.percent}%`"
            ),
        )

        # SERVER section
        embed.add_field(
            name=f"🏰 Server: {guild.name}",
            value=(
                f"**ID:** `{guild.id}`\n"
                f"**Owner:** {guild.owner.mention if guild.owner else 'Unknown'}\n"
                f"**Created:** <t:{int(guild.created_at.timestamp())}:R>\n"
                f"**Verification:** {verify}"
            ),
        )
        embed.add_field(
            name="👥 Members",
            value=(
                f"**Total:** `{total:,}`\n"
                f"**Humans:** `{humans:,}`\n"
                f"**Online:** `{online:,}`\n"
                f"**Bots:** `{bots:,}`"
            ),
        )
        embed.add_field(
            name="📢 Channels & Roles",
            value=(
                f"**Text:** `{text_ch}`\n"
                f"**Voice:** `{voice_ch}`\n"
                f"**Roles:** `{len(guild.roles) - 1}`\n"
                f"**Emojis:** `{len(guild.emojis)}/{guild.emoji_limit}`"
            ),
        )
        embed.add_field(
            name="🚀 Boost & Esports",
            value=(
                f"**Boost Level:** `{boost_level}`\n"
                f"**Boosters:** `{boosters}`\n"
                f"**Scrims:** `{scrim_count}`\n"
                f"**Tourneys:** `{tourney_count}`"
            ),
            inline=False,
        )

        embed.set_footer(
            text=f"Quotient Prime | Provided by Nobita",
            icon_url=self.bot.user.display_avatar.url,
        )
        await ctx.send(embed=embed, embed_perms=True)

    @app_commands.command(name="uptime", description="Check the bot's uptime and system status.")
    @app_commands.checks.cooldown(1, 10, key=lambda i: i.guild_id)
    async def uptime_slash(self, interaction: discord.Interaction):
        """Slash command: /uptime — shows bot uptime and system stats."""
        await interaction.response.defer()

        uptime_str = self.get_bot_uptime()
        ws_latency = round(self.bot.latency * 1000, 1)
        mem = psutil.virtual_memory()
        cpu = psutil.cpu_percent()

        embed = discord.Embed(
            title="⏱️ Bot Uptime",
            color=self.bot.color,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.add_field(name="🕒 Uptime", value=f"`{uptime_str}`", inline=False)
        embed.add_field(name="🏓 Ping", value=f"`{ws_latency} ms`", inline=True)
        embed.add_field(name="🖥️ CPU", value=f"`{cpu}%`", inline=True)
        embed.add_field(name="💾 RAM", value=f"`{mem.used >> 20}/{mem.total >> 20} MB`", inline=True)
        embed.add_field(name="🌐 Servers", value=f"`{len(self.bot.guilds)}`", inline=True)
        embed.set_footer(text=self.bot.config.FOOTER, icon_url=self.bot.user.display_avatar.url)

        await interaction.followup.send(embed=embed)

    @commands.command(name="uptime")
    @commands.cooldown(1, 10, commands.BucketType.guild)
    async def uptime_prefix(self, ctx: Context):
        """Check the bot's uptime — prefix version (quptime)."""
        uptime_str = self.get_bot_uptime()
        ws_latency = round(self.bot.latency * 1000, 1)
        mem = psutil.virtual_memory()
        cpu = psutil.cpu_percent()

        embed = discord.Embed(
            title="⏱️ Bot Uptime",
            color=self.bot.color,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.add_field(name="🕒 Uptime", value=f"`{uptime_str}`", inline=False)
        embed.add_field(name="🏓 Ping", value=f"`{ws_latency} ms`", inline=True)
        embed.add_field(name="🖥️ CPU", value=f"`{cpu}%`", inline=True)
        embed.add_field(name="💾 RAM", value=f"`{mem.used >> 20}/{mem.total >> 20} MB`", inline=True)
        embed.add_field(name="🌐 Servers", value=f"`{len(self.bot.guilds)}`", inline=True)
        embed.set_footer(text=self.bot.config.FOOTER, icon_url=self.bot.user.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command()
    async def dashboard(self, ctx: Context):
        await ctx.send(
            f"Here is the direct link to this server's dashboard:\n<https://quotientbot.xyz/dashboard/{ctx.guild.id}>"
        )

    @commands.hybrid_command()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def contributors(self, ctx):
        """People who made Quotient Possible."""
        url = f"https://api.github.com/repos/quotientbot/Quotient-Bot/contributors"

        e = discord.Embed(title=f"Project Contributors", color=self.bot.color, timestamp=self.bot.current_time)
        e.description = ""
        async with self.bot.session.get(url) as response:
            data = await response.json()
            for idx, contributor in enumerate(data, start=1):
                if contributor["type"] == "Bot":
                    continue

                e.description += (
                    f"`{idx:02}.` [{contributor['login']} ({contributor['contributions']})]({contributor['html_url']})\n"
                )

        e.description += "\n`–` Quotient Prime | Provided by Nobita"
        await ctx.send(embed=e)


async def setup(bot: Quotient) -> None:
    await bot.add_cog(Quomisc(bot))
    await bot.add_cog(Dev(bot))
    await bot.add_cog(QuoAlerts(bot))
