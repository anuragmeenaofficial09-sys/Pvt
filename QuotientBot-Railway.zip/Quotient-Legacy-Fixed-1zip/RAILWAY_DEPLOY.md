# Railway Deployment Guide

## Step 1 — GitHub pe upload karo

1. [github.com](https://github.com) → New Repository → Name: `quotient-bot` → Private → Create
2. Apne PC pe ye folder download karo (Replit se ZIP download)
3. Ya Replit terminal mein:

```bash
cd /home/runner/workspace/Quotient/Quotient-Legacy-Fixed-1zip
git init
git add .
git commit -m "Quotient Prime Bot"
git branch -M main
git remote add origin https://github.com/TERA_USERNAME/quotient-bot.git
git push -u origin main
```

---

## Step 2 — Railway pe PostgreSQL database banao

1. [railway.app](https://railway.app) → Login with GitHub
2. **New Project** → **Deploy PostgreSQL**
3. Database ban jayega — uska `DATABASE_URL` copy karo (Variables tab mein milega)

---

## Step 3 — Bot deploy karo

1. Same project mein → **New Service** → **GitHub Repo**
2. Apni `quotient-bot` repo select karo
3. **Variables** tab mein ye add karo:

| Variable | Value |
|----------|-------|
| `DISCORD_TOKEN` | Tera Discord bot token |
| `DATABASE_URL` | Step 2 ka PostgreSQL URL |

4. **Deploy** karo — Done! ✅

---

## Files jo Railway use karta hai (already ready hain)

| File | Kaam |
|------|------|
| `railway.toml` | Railway ko batata hai kaise start karna hai |
| `nixpacks.toml` | Python 3.11 install karta hai |
| `requirements.txt` | Sare packages install karta hai |
| `Procfile` | Start command |
| `start.py` | Bot start karta hai |

---

## Bot ka Discord Token kahan se milega?

1. [discord.com/developers/applications](https://discord.com/developers/applications)
2. Apna bot select karo → **Bot** tab → **Reset Token** → Copy
3. Railway mein `DISCORD_TOKEN` mein paste karo

---

## Bot invite link

Bot invite karne ke liye:
1. Developer Portal → OAuth2 → URL Generator
2. Scopes: `bot`, `applications.commands`
3. Bot Permissions: `Administrator`
4. Generated URL copy karo → Browser mein open karo → Server select karo
