# Quotient Bot — Hosting Guide

## Kahan bhi host karo (Railway, Render, VPS)

### Required Environment Variables
```
DISCORD_TOKEN=your_bot_token_here
DATABASE_URL=postgres://user:password@host/dbname
```

### Run Command
```bash
cd src && python3 bot.py
```

### Python Version
Python 3.11+

---

## Railway.app pe host karo (FREE, 24/7)

1. [railway.app](https://railway.app) pe account banao
2. "New Project" → "Deploy from GitHub repo" click karo
3. Ya "Empty Project" → "Add Service" → "GitHub Repo" select karo
4. Ye folder upload karo
5. Environment variables set karo:
   - `DISCORD_TOKEN` = tera bot token
   - `DATABASE_URL` = PostgreSQL URL (Railway khud deta hai free mein!)
6. Start command: `cd src && python3 bot.py`

### Railway pe free PostgreSQL:
- Project mein "Add Service" → "Database" → "PostgreSQL" add karo
- `DATABASE_URL` auto-set ho jaayega

---

## Render.com pe host karo (FREE tier)

1. [render.com](https://render.com) pe account banao
2. "New" → "Web Service" select karo
3. GitHub repo connect karo
4. Settings:
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `cd src && python3 bot.py`
5. Environment variables add karo

---

## UptimeRobot Setup (Bot ko jagte rakho)

Bot ka health check URL:
```
https://YOUR-DOMAIN/uptime
```

Steps:
1. [uptimerobot.com](https://uptimerobot.com) pe free account banao
2. "Add New Monitor" click karo
3. Monitor Type: "HTTP(s)"
4. URL: `https://YOUR-DOMAIN/uptime`
5. Monitoring Interval: 5 minutes
6. Save!

Bot jaagta rahega 24/7!

---

## All Commands List

### Prefix Commands (default prefix: `q`)
| Command | Aliases | Description |
|---------|---------|-------------|
| `qping` | - | Bot latency check |
| `qabout` | `qstats` | Bot statistics |
| `qstatus` | `qbotstatus`, `qbinfo` | Full bot & server status |
| `quptime` | - | Bot uptime |
| `qsetup` | - | Server setup |
| `qprefix` | - | Change server prefix |
| `qinvite` | `qinv` | Bot invite link |
| `qsource` | `qsrc` | Source code |
| `qserverinfo` | `qserver`, `qguildinfo` | Server info |
| `qscrims` | `qs`, `qsm` | Scrims management |
| `qtournaments` | `qtm`, `qt` | Tournament management |
| `qslotmanager` | `qslotm` | Slot manager |
| `qvote` | - | Vote for bot |
| `qvoteremind` | - | Vote reminder toggle |
| `qmoney` | - | Quo coins |
| `qcolor` | - | Change embed color (Premium) |
| `qfooter` | - | Change embed footer (Premium) |
| `qquickembed` | `qqe` | Quick embed maker |
| `qnickname` | `qnick` | Change nickname |
| `qbanlog` | - | Ban log setup |
| `qcontributors` | - | Bot contributors |

### Slash Commands (/)
| Command | Description |
|---------|-------------|
| `/uptime` | Bot uptime & system stats |
| `/scrims` | Scrims slash commands |
